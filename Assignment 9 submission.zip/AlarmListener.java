public interface AlarmListener {
    public void wakeUp();
}
