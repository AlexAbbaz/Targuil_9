public enum Trend {
    RISING, FALLING, STABLE
}
