public interface Observer {
    public void update(int data);
    public String getName();
}
