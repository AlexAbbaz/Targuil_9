public class Nimbus1PressureSensor extends Sensor {
    public Nimbus1PressureSensor() {
        super("pressure", 1100);
    }

    @Override
    public int read() {
        return RandomSupplier.getRnd().nextInt(100) + 950;
    }
}
